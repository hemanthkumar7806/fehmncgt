# RevAI Mentor SDK

A floating chat widget SDK for integrating AI-powered mentorship into Learning Management Systems (LMS).

## Features

- 🎯 **Floating Chat Widget** - Minimizable, expandable, and maximizable window states
- 🌊 **Streaming Responses** - Real-time token-by-token message display with SSE
- 📝 **Rich Content** - Markdown, code syntax highlighting, study plan visualization
- 🎨 **Customizable** - Themes, colors, positions, and sizes
- 🔌 **Event System** - Callbacks for all major interactions
- 📱 **Responsive** - Works on all screen sizes

## Installation

```bash
npm install @revature/ai-mentor-sdk
```

## Quick Start

```tsx
import { FloatingChatWidget } from '@revature/ai-mentor-sdk';

function App() {
  return (
    <FloatingChatWidget
      apiBaseUrl="https://your-backend-url.com"
      courseId="CS101"
      userId="user_123"
      title="AI Mentor"
      welcomeMessage="Hello! How can I help you today?"
    />
  );
}
```

## Configuration Options

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `apiBaseUrl` | `string` | **required** | Backend API URL |
| `authToken` | `string` | - | JWT token for authentication |
| `courseId` | `string` | - | Current course ID |
| `userId` | `string` | - | User ID |
| `position` | `'bottom-left' \| 'bottom-right' \| 'top-left' \| 'top-right'` | `'bottom-right'` | Widget position |
| `theme` | `ThemeConfig` | - | Theme customization |
| `darkMode` | `boolean` | `false` | Enable dark mode |
| `showSources` | `boolean` | `true` | Show source references |
| `showTimestamp` | `boolean` | `true` | Show message timestamps |

## Event Callbacks

```tsx
<FloatingChatWidget
  apiBaseUrl="https://api.example.com"
  onMessageSent={(message, sessionId) => {
    console.log('Message sent:', message);
  }}
  onMessageReceived={(response) => {
    console.log('Response received:', response);
  }}
  onError={(error) => {
    console.error('Error:', error);
  }}
  onSessionChange={(sessionId) => {
    console.log('Session changed:', sessionId);
  }}
/>
```

## Theme Customization

```tsx
<FloatingChatWidget
  apiBaseUrl="https://api.example.com"
  theme={{
    primaryColor: '#6366f1',
    backgroundColor: '#ffffff',
    surfaceColor: '#f8fafc',
    textColor: '#1e293b',
    borderRadius: 12,
  }}
/>
```

## Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## Documentation

See [SDK Documentation](./docs/SDK_DOCUMENTATION.md) for full API reference and examples.

## License

MIT
